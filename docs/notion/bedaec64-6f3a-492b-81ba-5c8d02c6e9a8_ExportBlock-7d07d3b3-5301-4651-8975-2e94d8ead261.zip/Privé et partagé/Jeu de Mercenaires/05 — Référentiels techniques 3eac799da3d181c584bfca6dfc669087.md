# 05 — Référentiels techniques

Registres transversaux utilisés par le moteur : formules, termes et constantes. Ces bases servent de **source technique unique** et ne dupliquent pas les règles métier.

Chaque formule destinée au code conserve un identifiant stable (`combat.melee.hit_probability`, etc.). Une vue **Combat V1** regroupe désormais les formules de combat actives sans mélanger les formules de personnage ou d’équipement.

[Formules de jeu](05%20%E2%80%94%20R%C3%A9f%C3%A9rentiels%20techniques/Formules%20de%20jeu%20b096926b35a04a96995cad7aa5544c31.csv)

[Termes de formule](05%20%E2%80%94%20R%C3%A9f%C3%A9rentiels%20techniques/Termes%20de%20formule%2029df19d52e964abf8956c8ae8371a4da.csv)

[Constantes de formule](05%20%E2%80%94%20R%C3%A9f%C3%A9rentiels%20techniques/Constantes%20de%20formule%202a25d0db802141bb8e0273935c2be8c2.csv)